package Project1.ClawMachine;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        ClawMachine machine = new ClawMachine();//object creation
        Scanner scanner=new Scanner(System.in);
        boolean continuePlaing=true;

        while (continuePlaing){
            System.out.println("Welcome to the Claw Machine");
            System.out.println("It cost 1€ Play");

            System.out.println("Current money in the machine:"+machine.getMoneyInTheBank()+"€");
            System.out.println("Enter the amount of money to play in €");

            int moneyPaid = scanner.nextInt();
            scanner.nextLine();//clearing the scanner buffer

            String result = machine.playGame(moneyPaid);//Game

            System.out.println(result);

            //Checking if player want to continue
            System.out.println("Do you want to play again?(Yes/No)");
            String playAgain = scanner.nextLine();
            if (!playAgain.equalsIgnoreCase("Yes")){
                continuePlaing=false;
            }

        }
    }
}
